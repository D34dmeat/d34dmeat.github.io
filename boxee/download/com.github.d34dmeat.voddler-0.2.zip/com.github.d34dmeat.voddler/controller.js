boxee.apiMinVersion=7.0;
boxee.reloadOnPageChange = true;
boxee.setMode(boxee.KEYBOARD_MODE);
